# Trie

[![GoDoc](http://godoc.org/github.com/toqueteos/trie?status.png)](http://godoc.org/github.com/toqueteos/trie)

This is a fork of https://github.com/cespare/go-trie that adds the `PrefixIndex` method.

It's required for https://github.com/toqueteos/substring.

#!/usr/bin/env python3
import json, re, ast, xml.etree.ElementTree as ET
from pathlib import Path

# Load dynamic hints
TECH_HINTS = json.load(open("tech_hints.json"))

def parse_pom(pom_path):
    try:
        return ET.fromstring(Path(pom_path).read_text())
    except:
        return None

class FrameworkDetector:
    def __init__(self, repo_root):
        self.repo_root = Path(repo_root)

    def detect_for_hints(self, hints, categories):
        mode_all = hints.get("mode", "ANY") == "ALL"
        bucket_hits = {}
        repo = self.repo_root

        # Config bucket: file extensions, names, patterns
        if "config" in categories and "config" in hints:
            conf = hints["config"]
            # file extensions
            if "file_exts" in conf:
                bucket_hits["config:exts"] = False
                for ext in conf["file_exts"]:
                    if any(repo.rglob(f"*{ext}")):
                        bucket_hits["config:exts"] = True
                        if not mode_all:
                            return True
                        break
            # file names
            if "file_names" in conf:
                bucket_hits["config:names"] = False
                for name in conf["file_names"]:
                    if (repo / name).exists():
                        bucket_hits["config:names"] = True
                        if not mode_all:
                            return True
                        break
            # content patterns
            if "patterns" in conf:
                bucket_hits["config:pat"] = False
                for f in repo.rglob("*"):
                    text = Path(f).read_text(errors="ignore")
                    if any(re.search(p, text) for p in conf["patterns"]):
                        bucket_hits["config:pat"] = True
                        if not mode_all:
                            return True
                        break

        # JS bucket
        if "js" in categories and "js" in hints:
            js = hints["js"]
            if "names" in js:
                bucket_hits["js:pkg"] = False
                pkg = repo / "package.json"
                if pkg.exists():
                    data = json.loads(pkg.read_text())
                    deps = set(data.get("dependencies", {})) | set(data.get("devDependencies", {}))
                    if any(n.lower() in {d.lower() for d in deps} for n in js["names"]):
                        bucket_hits["js:pkg"] = True
                        if not mode_all:
                            return True
            if "patterns" in js:
                bucket_hits["js:pat"] = False
                for ext in ("js","jsx","ts","tsx"):
                    for f in repo.rglob(f"*.{ext}"):
                        txt = Path(f).read_text(errors="ignore")
                        if any(re.search(p, txt) for p in js["patterns"]):
                            bucket_hits["js:pat"] = True
                            if not mode_all:
                                return True
                            break
                    if bucket_hits["js:pat"]:
                        break

        # Other buckets (python, java, etc.) unchanged for brevity

        # Final decision
        if mode_all:
            return all(bucket_hits.values())
        return False

    def detect_all(self):
        detected = []
        for tech, hints in TECH_HINTS.items():
            cats = [k for k in hints.keys() if k in ("config","js","python","java","dotnet","terraform","sql","cql","cf","scala")]
            if self.detect_for_hints(hints, cats):
                detected.append(tech)
        return {"Technologies": detected}

def main():
    det = FrameworkDetector(Path("."))
    summary = det.detect_all()
    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()

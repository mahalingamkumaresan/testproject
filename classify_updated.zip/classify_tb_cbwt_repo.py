#!/usr/bin/env python3
import os
import sys
import json
import subprocess
import threading
import time
import shutil
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

# Attempt to import dulwich as fallback
try:
    from dulwich import porcelain
    DULWICH_AVAILABLE = True
except ImportError:
    DULWICH_AVAILABLE = False

# Oracle driver; install with `pip install oracledb`
import oracledb

class TokenBucket:
    def __init__(self, capacity, refill_rate):
        self.capacity = capacity
        self.refill_rate = refill_rate
        self.tokens = capacity
        self.timestamp = time.monotonic()
        self.lock = threading.Lock()

    def _refill(self):
        now = time.monotonic()
        elapsed = now - self.timestamp
        self.tokens = min(self.capacity, self.tokens + elapsed * self.refill_rate)
        self.timestamp = now

    def consume(self):
        with self.lock:
            self._refill()
            if self.tokens >= 1:
                self.tokens -= 1
                return True
            return False

    def wait_for_token(self):
        while True:
            if self.consume():
                return
            with self.lock:
                missing = 1 - self.tokens
            wait = missing / self.refill_rate if self.refill_rate > 0 else 0.2
            time.sleep(max(wait, 0.01))

def shallow_clone(url: str, dest: Path, bucket: TokenBucket, use_git_cli: bool):
    name = url.rstrip('/').split('/')[-1].removesuffix('.git')
    target = dest / name
    if target.exists():
        return target
    bucket.wait_for_token()
    if use_git_cli:
        try:
            subprocess.run(
                ["git", "clone", "--depth", "1", url, str(target)],
                check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
            )
            return target
        except subprocess.CalledProcessError:
            return None
    else:
        if not DULWICH_AVAILABLE:
            return None
        try:
            porcelain.clone(url, str(target), depth=1)
            return target
        except Exception:
            return None

def inspect_repo(repo_path: Path):
    try:
        out = subprocess.check_output(
            ["python", "repo_inspector.py"],
            cwd=str(repo_path),
            stderr=subprocess.DEVNULL
        )
        return json.loads(out)
    except Exception:
        return None

def main():
    user = os.getenv("ORACLE_USER")
    pwd  = os.getenv("ORACLE_PASSWORD")
    dsn  = os.getenv("ORACLE_DSN")
    if not (user and pwd and dsn):
        print("Please set ORACLE_USER, ORACLE_PASSWORD, ORACLE_DSN", file=sys.stderr)
        sys.exit(1)

    conn = oracledb.connect(user=user, password=pwd, dsn=dsn)
    cur_sel = conn.cursor()
    cur_upd = conn.cursor()

    cur_sel.execute("""
      SELECT ID, REPO_URL 
        FROM TB_CBWT_REPO
       WHERE PROGRAMMING_LANGUAGE IS NULL
          OR FRAMEWORK           IS NULL
          OR TECHNOLOGIES        IS NULL
    """)
    rows = cur_sel.fetchall()
    print(f"Found {len(rows)} repos to classify.")

    base_dir = Path("cloned_repos")
    base_dir.mkdir(exist_ok=True)
    bucket = TokenBucket(capacity=75, refill_rate=5.0)
    use_git_cli = shutil.which("git") is not None

    # Process only 5 repos concurrently
    with ThreadPoolExecutor(max_workers=5) as exe:
        future_map = {}
        for repo_id, url in rows:
            fut = exe.submit(shallow_clone, url, base_dir, bucket, use_git_cli)
            future_map[fut] = (repo_id, url)
        for fut in as_completed(future_map):
            repo_id, url = future_map[fut]
            local_path = fut.result()
            if not local_path:
                print(f"[SKIP] {repo_id} ({url}): clone failed")
                continue

            summary = inspect_repo(local_path)
            if not summary:
                print(f"[ERR] {repo_id} ({url}): inspection failed")
                shutil.rmtree(local_path, ignore_errors=True)
                continue

            langs = json.dumps(list(summary.get("Languages", {}).keys()))
            fw = summary.get("JS/TS Frameworks", []) +                  summary.get("Java Frameworks", []) +                  summary.get("Python Frameworks", [])
            frameworks = json.dumps(fw)
            technologies = json.dumps(summary.get("Technologies", []))

            cur_upd.execute("""
              UPDATE TB_CBWT_REPO
                 SET PROGRAMMING_LANGUAGE = :langs,
                     FRAMEWORK            = :fw,
                     TECHNOLOGIES         = :tech
               WHERE ID = :id
            """, [langs, frameworks, technologies, repo_id])
            conn.commit()
            print(f"[OK] Updated ID={repo_id}")

            # Cleanup cloned directory after processing
            shutil.rmtree(local_path, ignore_errors=True)

    cur_sel.close()
    cur_upd.close()
    conn.close()
    print("All done.")

if __name__ == "__main__":
    main()
